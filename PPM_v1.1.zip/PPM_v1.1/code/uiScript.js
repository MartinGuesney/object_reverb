var cercle = new Array();
var reverbNodes = new Array() 
var speakers = new Array();

var ratio = 1;
var xOffset = 0;
var yOffset = 0;
var oldMouseX = 0;
var oldMouseY = 0;
var oldxOffset = 0;
var oldyOffset = 0;

var yScale = 10;
var dragging = false;

var number = 0;
var reverbNodesNumber = 9;
var speakerNumber = 15;

var countSelected = 0;

var SelectedIndex = -1;
var SelectedIndexReverb = -1;

var colorUnselectedSource = color([233,196,106,255]);
var colorSelectedSource = color([244, 162, 97, 255]);
var colorUnselectedReverb = color([42,157,143,150]);
var colorSelectedReverb = color([42,157,143,255]);

inlets = 1;
outlets = 1;

bang();



/* 
=====================================================================================================
=====================================================================================================
Initialisation
=====================================================================================================
=====================================================================================================
*/
function bang() {
	
	var height = box.rect[3] - box.rect[1]; 
	var width = box.rect[2] - box.rect[0]; 
	ratio = width / height;
	
	xOffset = 0;
	yOffset = 0;
	oldxOffset = 0;
	oldyOffset = 0;
	oldxOffset = 0;
	oldyOffset = 0;
	
	yScale = 10;
	
	sketch.glclearcolor(0.8,0.8,0.8,1); // reset background
	sketch.glclear();
	
	sketch.fontsize(11); 
		
	for (i = 0; i < reverbNodesNumber; i++) {
		var x, y, j;
		x = (Math.random() - 0.5) * 2 * yScale;
		y = (Math.random() - 0.5) * 2 * yScale;
		j = i + 1;
	    reverbNodes[i] = new Cercle(x, y, "N" + j, "reverb", colorUnselectedReverb, colorSelectedReverb);
	}
	
	for (i = 0; i < speakerNumber; i++) {
		speakers[i] = new Speaker();
	}
	
	
	draw();
}




function uiSetup(n) {
	if (n > number) {
		for (var i = number; i < n; i++) {
			j = cercle.length + 1;
			cercle.push(new Cercle( 0.5 * cercle.length, 0.5 * cercle.length , "object" + j, "source", colorUnselectedSource, colorSelectedSource));	
		}
	}
	if (n < number) {
		for (var i = n; i < number; i++) {
			cercle.pop();
		}
	}
	number = n;

	draw();
}




/*
=====================================================================================================
===================================================================================================== 
draw
=====================================================================================================
=====================================================================================================
*/
function draw() {
	
	sketch.glclearcolor(0.80,0.80,0.80,1);  // reset background
	sketch.glclear();	
	
	sketch.glcolor(0.95,0.95,0.95,1);          // axes x et y
	sketch.linesegment(-xOffset,1,0,-xOffset,-1,0);
	sketch.linesegment(-1 * ratio,-yOffset,0,1 * ratio,-yOffset,0);
	             
	sketch.textalign("center","center");
	var yMax = yScale * (1 + yOffset);
	var yMin = - yScale * (1 - yOffset);
	sketch.moveto(0.05,0.95);
	sketch.text(yMax.toFixed(1));
	sketch.moveto(0.05,-0.95);
	sketch.text(yMin.toFixed(1));
	var xMax = yScale * (ratio + xOffset);
	var xMin = - yScale * (ratio - xOffset);
	sketch.moveto(0.95 * ratio,0.05);
	sketch.text(xMax.toFixed(1));
	sketch.moveto(-0.95 * ratio,0.05);
	sketch.text(xMin.toFixed(1));
	
	for (i = 0; i < speakerNumber; i++ ){
		speakers[i].showSpeaker();
	}
	
	for (i = 0; i < reverbNodesNumber; i++ ){
		reverbNodes[i].show();
	}
	
	for (i = 0; i < number; i++ ){
		cercle[i].show();
	}
	
	refresh();
}



/*
=====================================================================================================
=====================================================================================================
Zooming
=====================================================================================================
=====================================================================================================
*/ 
function zoomout() {
	yScale = yScale * 1.33;
	xOffset = xOffset / 1.33
	yOffset = yOffset / 1.33
		
	for (i = 0; i < number; i++){
		cercle[i].offset();
	}
	for (i = 0; i < reverbNodesNumber; i++){
		reverbNodes[i].offset();
	}
	for (i = 0; i < speakerNumber; i++){
		speakers[i].offset();
	}
	
	draw();
}


function zoomin() {
	yScale = yScale / 1.33;
	xOffset = xOffset * 1.33
	yOffset = yOffset * 1.33
	
	for (i = 0; i < number; i++){
		cercle[i].offset();
	}
	for (i = 0; i < reverbNodesNumber; i++){
		reverbNodes[i].offset();
	}
	for (i = 0; i < speakerNumber; i++){
		speakers[i].offset();
	}
	
	draw();
}



/*
=====================================================================================================
=====================================================================================================
Gestion des inlets
=====================================================================================================
=====================================================================================================
*/ 
function source(i, x , y, objectName) {
	if (!dragging) {
		cercle[i-1].x = x;
		cercle[i-1].y = y;
		cercle[i-1].wx = x / (ratio * yScale) ;
		cercle[i-1].wy = y / yScale ;
		cercle[i-1].objectName = objectName;
	
		draw();
	}
}

function reverb(i, x , y) {
	if (!dragging) {
		reverbNodes[i-1].x = x;
		reverbNodes[i-1].y = y;
		reverbNodes[i-1].wx = x / (ratio * yScale) ;
		reverbNodes[i-1].wy = y / yScale ;
	
		draw();
	}
}

function spk(i, x , y) {
	if (!dragging) {
		speakers[i-1].x = x;
		speakers[i-1].y = y;
		speakers[i-1].wx = x / (ratio * yScale) ;
		speakers[i-1].wy = y / yScale ;
	
		draw();
	}
}

function dumpout () {
	for (i=0; i<number; i++) {
		var j = i + 1;
		outlet(0, "s" + j, cercle[i].x, cercle[i].y);	
	}
	for (i=0; i<reverbNodesNumber; i++) {
		var j = i + 1;
		outlet(0, "n" + j, reverbNodes[i].x, reverbNodes[i].y);	
	}
}



/* 
=====================================================================================================
=====================================================================================================
Interaction et souris
=====================================================================================================
=====================================================================================================
*/
function onidle(mouseX, mouseY) {                 // on check si la souris est sur le cercle
	
	dragging = false;
	
	countSelected = 0;
	SelectedIndex = -1;
	SelectedIndexReverb = -1;
	
	wMouseX = sketch.screentoworld(mouseX,mouseY)[0];
	wMouseY = sketch.screentoworld(mouseX,mouseY)[1]; 
	
	for (i=0; i<number; i++){
		if ( wMouseX - cercle[i].wx > -0.05 && wMouseX - cercle[i].wx < 0.05 && wMouseY - cercle[i].wy > -0.05 && wMouseY - cercle[i].wy < 0.05) {
			cercle[i].state = true;
			countSelected = countSelected + 1;
			SelectedIndex = i;
		}
		else {
			cercle[i].state = false;
		}
	}
	
	for (i=0; i<reverbNodesNumber; i++){
		if ( wMouseX - reverbNodes[i].wx > -0.05 && wMouseX - reverbNodes[i].wx < 0.05 && wMouseY - reverbNodes[i].wy > -0.05 && wMouseY - reverbNodes[i].wy < 0.05) {
			reverbNodes[i].state = true;
			countSelected = countSelected + 1;
			SelectedIndexReverb = i;
		}
		else {
			reverbNodes[i].state = false;
		}
	}
	
	oldMouseX = wMouseX;
	oldMouseY = wMouseY;
	oldxOffset = xOffset;
	oldyOffset = yOffset;
	
	draw();
}
onidle.local = 1; //private


function ondrag(mouseX, mouseY) {
	dragging = true;
	
	wMouseX = sketch.screentoworld(mouseX,mouseY)[0];
	wMouseY = sketch.screentoworld(mouseX,mouseY)[1]; 
	
	if (countSelected > 0) {                           // si au moins un objet est selectionné on le bouge
		if (SelectedIndex > -1) {
			cercle[SelectedIndex].drag();
			var i = SelectedIndex + 1;
			outlet(0, "s" + i, cercle[SelectedIndex].x, cercle[SelectedIndex].y);
		}
		if (SelectedIndexReverb > -1) {
			reverbNodes[SelectedIndexReverb].drag();
			var i = SelectedIndexReverb + 1;
			outlet(0, "n" + i, reverbNodes[SelectedIndexReverb].x, reverbNodes[SelectedIndexReverb].y);
		}
	} 
	else {                                             // sinon on change l'offset
	xOffset = oldxOffset + oldMouseX - wMouseX;
	yOffset = oldyOffset + oldMouseY - wMouseY;
		for (i=0; i<number; i++) {
			cercle[i].offset();
		}
		for (i=0; i<reverbNodesNumber; i++) {
			reverbNodes[i].offset();
		}
		for (i=0; i<speakerNumber; i++) {
			speakers[i].offset();
		}		
	}
	
	draw();
}
ondrag.local = 1; //private



function onresize()
{
	var height = box.rect[3] - box.rect[1]; 
	var width = box.rect[2] - box.rect[0]; 
	ratio = width / height;
	
	draw();
}
onresize.local = 1; //private



/* 
=====================================================================================================
=====================================================================================================
Classes
=====================================================================================================
=====================================================================================================
*/
function Cercle(x,y, objectName, objectType, colorUnselected, colorSelected) { // class Cercle
	this.x = x;
	this.y = y;
	this.objectName = objectName;
	this.objectType = objectType;
	this.wx = x / yScale;
	this.wy = y / yScale;
	this.colorUnselected = colorUnselected;
	this.colorSelected = colorSelected;
	this.state = false;
	this.show = show;
	this.drag = drag;
	this.offset = offset;
}
Cercle.local = 1; //private


function Speaker(x,y) {
	this.x = x;
	this.y = y;
	this.wx = x / yScale;
	this.wy = y / yScale;	
	this.showSpeaker = showSpeaker;
	this.offset = offset;
}
Speaker.local = 1; //private



/* 
=====================================================================================================
=====================================================================================================
fonctionnalitées de classes
=====================================================================================================
=====================================================================================================
*/
function show() {
	sketch.moveto(this.wx, this.wy);
	sketch.glcolor(0,0,0,1);
	sketch.framecircle(0.03);	
	
	if (this.state) {                       
		sketch.glcolor(this.colorSelected);
		sketch.circle(0.03)	;
		
		sketch.glcolor(0,0,0);
		
		sketch.textalign("center","center");
		sketch.moveto(this.wx, this.wy - 0.05);
		sketch.text(this.x.toFixed(2) + " ; " + this.y.toFixed(2));
	}	
	else {              // sinon on le colorie en noir
		sketch.moveto(this.wx, this.wy);
		sketch.glcolor(this.colorUnselected);
		sketch.circle(0.03)	;
	}
	
	sketch.glcolor(0,0,0,1);
	sketch.textalign("center","center");
	sketch.moveto(this.wx, this.wy);
	sketch.text(this.objectName);		
}
show.local = 1; //private


function showSpeaker() {
	sketch.moveto(this.wx, this.wy);
	sketch.glcolor(0.1,0.1,0.1,1);	
	sketch.quad(this.wx - 0.015, this.wy + 0.015, 0, this.wx + 0.015, this.wy + 0.015, 0, this.wx + 0.015, this.wy - 0.015, 0, this.wx - 0.015, this.wy - 0.015, 0)
}
showSpeaker.local = 1; //private




function drag() {                               // permet de déplacer les objets avec la souris
	this.x = yScale * (wMouseX + xOffset);
	this.y = yScale * (wMouseY + yOffset);
	this.wx = wMouseX;
	this.wy = wMouseY;	
}
drag.local = 1; //private


function offset() {
	this.wx = this.x / yScale - xOffset;
	this.wy = this.y / yScale - yOffset;	
}
offset.local = 1; //private



/* 
=====================================================================================================
=====================================================================================================
Utilitaires
=====================================================================================================
=====================================================================================================
*/
function color(a) {
	a[0] = a[0] / 255;
	a[1] = a[1] / 255;
	a[2] = a[2] / 255;
	a[3] = a[3] / 255;
	return a;
}
color.local = 1;
