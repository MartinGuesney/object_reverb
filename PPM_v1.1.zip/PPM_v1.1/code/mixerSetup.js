// Global variables
var numObjects = 0;
var maxObjects = 16;
var objectSize = 63;
var objectOffset = 0;



function mixerSetup(n) {
	
	if (n < 0) a = 0;
	if (n > maxObjects) n = maxObjects;
	
	if (n > numObjects) {
		for (var i=numObjects; i<n; i++) {
			j = i + 1;
			// create new inlets :
			var inlet_ = this.patcher.newdefault( objectSize * i, 40, "inlet", "@varname", "inlet" + j)
			//create new channel strips :
			var channelStrip = this.patcher.newdefault( objectSize * i, 100, "bpatcher", "channelStrip", "@varname", "source" + j, "@args", "s" + j, "@presentation", "1", "@patching_rect", objectSize * i, 100, 66, 600, "@presentation_rect", objectSize * i, 0, 66, 600);
			// connect inlet to the channel strip :
			patcher.connect(inlet_, 0, channelStrip, 0);
			// connect the adc~ to the channel strip :
			patcher.connect( this.patcher.getnamed("adc"), i, channelStrip, 0);	
		}
		numObjects = n;
	}
	
	
	if (n < numObjects) {
		for (var i = n; i < numObjects; i++) {
			j = i + 1;
			// remove old inlets :	
			this.patcher.remove( this.patcher.getnamed("inlet" + j) );	
			// remove old channel strips :	
			this.patcher.remove( this.patcher.getnamed("source" + j) );	
		}
		numObjects = n;
	}
	
	// move the master :
	this.patcher.script("sendbox", "master", "patching_rect", objectSize * numObjects, 100, 126, 600);
	this.patcher.script("sendbox", "master", "presentation_rect", objectSize * numObjects, 0, 126, 600);
}

function reset() {
	numObjects = 0;
}

function number() {
	post(numObjects);
	post();
}
