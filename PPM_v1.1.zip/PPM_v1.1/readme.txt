============================================
PPM_v1.1
janvier 2020

Spatialisateur et réverbérateur WFS pour Max (version 7 ou 8)
Le patch peut gérer 8 objets et jusqu’à 15 enceintes (ligne ou couronne)
https://github.com/MartinGuesney/object_reverb
janvier 2020
============================================



Configuration du système d’écoute (panneau vert en haut à gauche) :
	
- C’est ici que l’on précise la position des HP dans l’espace pour que l’algorithme de WFS fonctionne correctement
- Le bouton <Edit> permet d’accéder au fichier speaker_layout.txt dans lequel les coordonnées des N HP (en mètres) sont précisées sous la forme : 
«1, x_1 y_1; 
2, x_2 y_2;
…
N, x_N y_N; »
- Le bouton <Configure> permet de transmettre la position des HP à l’algorithme. En appuyant dessus les HP apparaissent sur l’interface graphique de spatialisation sous la forme de carrés noirs.
- Dans le cas d’une ligne WFS, on préférera fixer la position de l’axe des ordonnées à une valeur strictement supérieure à 0 (par exemple 1m) dans la déclaration des HP (pour éviter des soucis dans l’algorithme de WFS).




Créations des objets (panneau orange sous le Mixer/Master) :

- Le Mixer ne doit contenir aucune tranche (à l’exception du Master) à l’ouverture du patch. Si ce n’est pas le cas, ouvrez et déverouillez le patch «mixer », puis supprimez les tranches objets (sauf le master) ainsi que les inlets associées. Fermez le patch et entrez le chiffre 0 dans le panneau orange de création d’objets.
- Il vous suffit alors d’entrer le nombre d’objets souhaité (8 maximum) dans le panneau orange de création d’objets. Les tranches objets apparaissent à la gauche du master et sur l’interface graphique de spatialisation.
- Appuyer de nouveau sur <Configure> dans le panneau de configuration du système d’écoute pour transmettre la position des HP aux tranches nouvellement créées.


Le patch est prêt à être utilisé.





============================================
Précisions 
============================================

Snapshots (panneau jaune tout à gauche):

- Ce onglet permet de sauvegarder l’état du patch à un instant t (position des noeuds, des objets, niveaux etc). On peut sauvegarder jusqu’à 5 snapshots du patch et les rappeler à la volée via les options de « store » et « recall ». 
« storagewindow »permet de visualiser tous les paramètres du patch.



Calcul des coefficients pour la réverbération: 

Bus d’envoi Early et Late : au sein de chaque tranche objet (patch « Channel_Strip ») on retrouve le bus d’envoi pour les early via le patch « toEarly » et le bus d’envoi vers le diffus via le patch « toLate ». On y calcule la distance entre l’objet et les noeuds pour en déduire les 9 gains et retards à appliquer. 
Pour les Early on a deux paramètres supplémentaires : 
- Size qui multiplie simplement la valeur des retards par un coefficient compris entre 0.5 et 2 
- Densité qui change la loi d’atténuation. La loi est de la forme 1/(1+r^(density)). Avec le potard à gauche on est de la forme 1/(1+r) (loi « naturelle ») et avec le potard à droite on n’a aucune atténuation.

Coefficient interne au SDN : à l’intérieur du patch « SDN9 », on trouve le sous-patch « NodeToNodeDelay » (panneau vert) dans lequel on calcule la distance entre chaque noeud du réseau et à partir desquelles on trouve les valeurs de retards internes au réseau (les gains sont contrôlés par la valeur de t_60). C’est la qu’intervient le paramètre de « Scale » qui multiplie les retards par un facteur compris en 0.2 et 10.